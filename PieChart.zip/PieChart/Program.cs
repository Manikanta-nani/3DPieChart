﻿using System;
using System.IO;
using Aspose.Cells;
using Aspose.Cells.Drawing;
using System.Drawing;
using Aspose.Cells.Charts;
using System.Net.NetworkInformation;
using System.Runtime.ConstrainedExecution;

namespace PieChart
{
    internal class Program
    {
        static void Main(string[] args)
        {
            PieChartNOExcelFIle();
        }
        public static void Run()
        {
            
            Workbook book = new Workbook();
            const string outputDir = @"d:\samples\";
            book.Worksheets[0].Name = "DataSheet"
            Worksheet dataSheet = book.Worksheets["DataSheet"];

        
            Worksheet sheet = book.Worksheets.Add("MyChart");
            dataSheet.Cells["B1"].PutValue(1);
            dataSheet.Cells["B2"].PutValue(2);
            dataSheet.Cells["B3"].PutValue(3);
            dataSheet.Cells["A1"].PutValue("A");
            dataSheet.Cells["A2"].PutValue("B");
            dataSheet.Cells["A3"].PutValue("C");
            ChartCollection charts = sheet.Charts;
            int chartSheetIdx = charts.Add(ChartType.Pie3D, 5, 0, 25, 15);
            Aspose.Cells.Charts.Chart chart = book.Worksheets["MyChart"].Charts[0];
            chart.PlotArea.Area.BackgroundColor = Color.White;
            chart.ChartArea.Area.BackgroundColor = Color.White;
            chart.PlotArea.Area.ForegroundColor = Color.White;
            chart.ChartArea.Area.ForegroundColor = Color.White;
            chart.ShowLegend = false;
            chart.NSeries.Add("DataSheet!B1:B3", true);
            chart.NSeries.CategoryData = "DataSheet!A1:A3";

            // Get the Data Series
            Aspose.Cells.Charts.Series ser = chart.NSeries[0];

            // Apply the 3-D formatting
            ShapePropertyCollection spPr = ser.ShapeProperties;
            Format3D fmt3d = spPr.Format3D;

            // Specify Bevel with its height/width
            Bevel bevel = fmt3d.TopBevel;
            bevel.Type = BevelPresetType.Circle;
            bevel.Height = 2;
            bevel.Width = 5;

            // Specify Surface material type
            fmt3d.SurfaceMaterialType = PresetMaterialType.WarmMatte;

            // Specify surface lighting type
            fmt3d.SurfaceLightingType = LightRigType.ThreePoint;

            // Specify lighting angle
            fmt3d.LightingAngle = 20;
            ser.Area.BackgroundColor = System.Drawing.Color.Maroon;
            ser.Area.ForegroundColor = Color.Maroon;
            ser.Border.Color = Color.Maroon;
            book.Save(outputDir + "Test123.xlsx");

            Console.WriteLine("Applying3DFormat executed successfully.");
            Workbook workbook = new Workbook(outputDir + "Test123.xlsx");
            Worksheet ws1 = workbook.Worksheets[1];
            Chart ch = ws1.Charts[0];
            ch.ToPdf(outputDir + "test123.pdf", 7, 7, PageLayoutAlignmentType.Center, PageLayoutAlignmentType.Center);

            Console.WriteLine("CreateChartPDFWithDesiredPageSize executed successfully.");

        }


        public static void Run2()
        {
            
            Workbook book = new Workbook();
            const string outputDir = @"d:\samples\";
            book.Worksheets[0].Name = "DataSheet";
            Worksheet dataSheet = book.Worksheets["DataSheet"];
            Worksheet sheet = book.Worksheets.Add("MyChart");
            dataSheet.Cells["B1"].PutValue(1);
            dataSheet.Cells["B2"].PutValue(2);
            dataSheet.Cells["B3"].PutValue(3);
            dataSheet.Cells["A1"].PutValue("A");
            dataSheet.Cells["A2"].PutValue("B");
            dataSheet.Cells["A3"].PutValue("C");
            ChartCollection charts = sheet.Charts;
            int chartSheetIdx = charts.Add(ChartType.Pie3D, 5, 0, 25, 15);
            Aspose.Cells.Charts.Chart chart = book.Worksheets["MyChart"].Charts[0];
            chart.PlotArea.Area.BackgroundColor = Color.White;
            chart.ChartArea.Area.BackgroundColor = Color.White;
            chart.PlotArea.Area.ForegroundColor = Color.White;
            chart.ChartArea.Area.ForegroundColor = Color.White;
            chart.ShowLegend = false;
            chart.NSeries.Add("DataSheet!B1:B3", true);
            chart.NSeries.CategoryData = "DataSheet!A1:A3";
            Aspose.Cells.Charts.Series ser = chart.NSeries[0];
            ShapePropertyCollection spPr = ser.ShapeProperties;
            Format3D fmt3d = spPr.Format3D;
            Bevel bevel = fmt3d.TopBevel;
            bevel.Type = BevelPresetType.Circle;
            bevel.Height = 2;
            bevel.Width = 5;

            // Specify Surface material type
            fmt3d.SurfaceMaterialType = PresetMaterialType.WarmMatte;

            // Specify surface lighting type
            fmt3d.SurfaceLightingType = LightRigType.ThreePoint;

            // Specify lighting angle
            fmt3d.LightingAngle = 20;

            // Specify Series background/foreground and line color
            ser.Area.BackgroundColor = System.Drawing.Color.Maroon;
            ser.Area.ForegroundColor = Color.Maroon;
            ser.Border.Color = Color.Maroon;

            // Save the Excel file
            // book.Save(outputDir + "outputApplying3DFormat.xlsx");
            book.Save(outputDir + "Test123.xlsx");

            Console.WriteLine("Applying3DFormat executed successfully.");

            // Open the existing excel file which contains the column chart.
            Workbook workbook = new Workbook(outputDir + "Test123.xlsx");
            //Access first worksheet.
            Worksheet ws1 = workbook.Worksheets[1];

            //Access first chart inside the worksheet.
            Chart ch = ws1.Charts[0];

            //Create chart pdf with desired page size.
            ch.ToPdf(outputDir + "test123.pdf", 7, 7, PageLayoutAlignmentType.Center, PageLayoutAlignmentType.Center);

            Console.WriteLine("CreateChartPDFWithDesiredPageSize executed successfully.");

        }


        public static void PieChart()

        {

            const string outputDir = @"d:\samples\";

            Workbook workbook = new Workbook();

            Worksheet sheet = workbook.Worksheets[0];

            sheet.Cells["A1"].PutValue("Products");

            sheet.Cells["B1"].PutValue("Users");

            sheet.Cells["A2"].PutValue("Aspose.Cells");

            sheet.Cells["B2"].PutValue(10000);

            sheet.Cells["A3"].PutValue("Aspose.Slides");

            sheet.Cells["B3"].PutValue(8000);

            sheet.Cells["A4"].PutValue("Aspose.Words");

            sheet.Cells["B4"].PutValue(12000);

            Chart productsChart;

            int chartIdx = sheet.Charts.Add(ChartType.Pie3D, 7, 0, 20, 6);

            productsChart = sheet.Charts[chartIdx];

            int seriesIdx = productsChart.NSeries.Add("=Sheet1!$B$2:$B$4", true);

            Series nSeries = productsChart.NSeries[seriesIdx];
            ShapePropertyCollection spPr = nSeries.ShapeProperties;
            Format3D fmt3d = spPr.Format3D;

            // Specify Bevel with its height/width
            Bevel bevel = fmt3d.TopBevel;
            bevel.Type = BevelPresetType.Circle;
            bevel.Height = 2;
            bevel.Width = 5;
            fmt3d.SurfaceMaterialType = PresetMaterialType.WarmMatte;
            fmt3d.SurfaceLightingType = LightRigType.ThreePoint;
            fmt3d.LightingAngle = 20;


            nSeries.XValues = "=Sheet1!$A$2:$A$4";

            productsChart.Title.Text = "Users";

            sheet.AutoFitColumn(0);

            workbook.Save(outputDir + "test124.xlsx");
            Workbook workbook1 = new Workbook(outputDir + "test124.xlsx");
            Worksheet ws1 = workbook.Worksheets[0];

            //Access first chart inside the worksheet.
            Chart ch = ws1.Charts[0];

            //Create chart pdf with desired page size.
            ch.ToPdf(outputDir + "test124.pdf", 7, 7, PageLayoutAlignmentType.Center, PageLayoutAlignmentType.Center);

            Console.WriteLine("CreateChartPDFWithDesiredPageSize executed successfully.");

        }
        public static void PieChartNOExcelFIle()

        {

            const string outputDir = @"d:\samples\";

            Workbook workbook = new Workbook();

            Worksheet sheet = workbook.Worksheets[0];

            sheet.Cells["A1"].PutValue("Category");

            sheet.Cells["B1"].PutValue("Allotment");

            sheet.Cells["A2"].PutValue("Education");

            sheet.Cells["B2"].PutValue(10000);

            sheet.Cells["A3"].PutValue("Savings");

            sheet.Cells["B3"].PutValue(8000);

            sheet.Cells["A4"].PutValue("spending");

            sheet.Cells["B4"].PutValue(12000);

            Chart productsChart;

            int chartIdx = sheet.Charts.Add(ChartType.Pie3D, 7, 0, 20, 6);

            productsChart = sheet.Charts[chartIdx];

            int seriesIdx = productsChart.NSeries.Add("=Sheet1!$B$2:$B$4", true);

            Series nSeries = productsChart.NSeries[seriesIdx];
            ShapePropertyCollection spPr = nSeries.ShapeProperties;
            Format3D fmt3d = spPr.Format3D;

            // Specify Bevel with its height/width
            Bevel bevel = fmt3d.TopBevel;
            bevel.Type = BevelPresetType.Circle;
            bevel.Height = 2;
            bevel.Width = 5;
            fmt3d.SurfaceMaterialType = PresetMaterialType.WarmMatte;
            fmt3d.SurfaceLightingType = LightRigType.ThreePoint;
            fmt3d.LightingAngle = 20;


            nSeries.XValues = "=Sheet1!$A$2:$A$4";

            productsChart.Title.Text = "Users";

            sheet.AutoFitColumn(0);


            //Create chart pdf with desired page size.
            productsChart.ToPdf(outputDir + "test125.pdf", 7, 7, PageLayoutAlignmentType.Center, PageLayoutAlignmentType.Center);

            Console.WriteLine("CreateChartPDFWithDesiredPageSize executed successfully.");

        }

    }
}
